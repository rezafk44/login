export const environment = {
  production: true,
  firebaseAPIKey: 'AIzaSyBNDASFTHW_rA6SHX89F3BHKV1xlOFUwtA',
  mapsAPIKey: 'AIzaSyCrepyAvtAtWYhgeZv4ZSdCHNS2t4t4SnU',
};
